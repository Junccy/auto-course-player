// ==UserScript==
// @name         理工智课1.1
// @namespace    local.whut.autowatch
// @version      1.1
// @description  文档并行、视频串行；服务器核验、断点继续和失败汇总。
// @match        https://whut.ai-augmented.com/app/jx-web/*
// @run-at       document-start
// @noframes
// @sandbox      raw
// @grant        unsafeWindow
// @grant        GM_openInTab
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        window.close
// ==/UserScript==

(function (factory) {
  'use strict';
  const core = factory();
  if (typeof module === 'object' && module.exports) module.exports = core;
  else core.boot().catch(error => console.error('[自主观看助手]', error));
})(function () {
  'use strict';
  const VERSION = '1.1';
  const PREFIX = 'whut-watch-v1:';
  const API = '/api/jx-iresource';
  const RATES = [16, 8, 4, 2, 1];
  const FINALS = new Set(['success', 'failed', 'skipped', 'already']);
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const uid = () => crypto.randomUUID();
  const plain = value => value && typeof value.toJS === 'function' ? value.toJS() : value;
  const finished = value => !!value && (value.finished === true || value.finish === 2);
  const errorText = error => String(error?.message || error).slice(0, 240);
  const natural = (a, b) => a.localeCompare(b, 'zh-CN', { numeric: true });

  class WatchError extends Error {
    constructor(message, kind = 'task', code = null) { super(message); this.kind = kind; this.code = code; }
  }
  async function readMediaHistory(read, quoteId) {
    let data;
    try { data = await read(`/vod/duration/${encodeURIComponent(quoteId)}`); }
    catch (error) {
      if (error.kind !== 'auth' && error.kind !== 'cancelled' && Number(error.code) === 60009
        && String(error.message || '').trim().toLowerCase() === 'media history not exist') {
        return { historyExists: false, played: 0, duration: 0, watched_duration: 0 };
      }
      throw error;
    }
    const record = data && typeof data === 'object' ? data : {};
    const played = Number(record.played ?? 0), watched = Number(record.watched_duration ?? 0);
    if (!Number.isFinite(played) || played < 0 || !Number.isFinite(watched) || watched < 0) throw new WatchError('网站返回的观看时长无效');
    return { ...record, historyExists: Object.hasOwn(record, 'played') || Object.hasOwn(record, 'watched_duration'), played, watched_duration: watched };
  }
  async function initializeVideoHistory(video, read, hooks) {
    const existing = await read();
    if (existing.historyExists) return existing;
    hooks.notify('首次观看，快速实际播放一小段以建立历史记录');
    const previousRate = video.playbackRate;
    try {
      applyVideoRate(video, hooks.preferredRate || 16);
      await hooks.active(); await hooks.start();
      let lastTime = video.currentTime, played = 0;
      for (let tick = 0; tick < 120 && played < 4.5 && !video.ended; tick++) {
        await hooks.active();
        if (video.paused) await hooks.start();
        await hooks.wait(100);
        const delta = video.currentTime - lastTime;
        if (!video.seeking && delta > 0 && delta <= Math.max(2, video.playbackRate * 2)) played += delta;
        lastTime = video.currentTime;
      }
      // A genuine pause lets the original player save the genuinely played interval.
      video.pause();
      return await pollHistory(read, record => record.historyExists, hooks);
    } finally {
      video.pause(); video.playbackRate = previousRate;
    }
  }
  function applyVideoRate(video, preferred = 16) {
    const first = Math.max(0, RATES.indexOf(preferred));
    for (const rate of RATES.slice(first)) {
      try { video.playbackRate = rate; if (Math.abs(video.playbackRate - rate) < 0.01) return rate; }
      catch { /* Try the next rate the browser can actually support. */ }
    }
    throw new WatchError('浏览器不支持所需播放速度');
  }
  async function startVideoPlayback(video, hooks) {
    let aborts = 0, mutedAttempt = !!video.muted;
    for (;;) {
      await hooks.active();
      const player = hooks.player?.();
      // Aliplayer.play() also initializes a lazy source and hides its cover.
      // Calling only HTMLVideoElement.play() skips those SDK operations.
      const nativePlayer = player?.tag === video && typeof player.play === 'function' ? player : null;
      if (!video.paused && !video.ended && !nativePlayer) return;
      try {
        nativePlayer?.play();
        await hooks.play();
        return;
      } catch (error) {
        if (error.name === 'AbortError' && aborts++ < 2) {
          // Player initialization can briefly interrupt play(). Recheck the queue
          // and visibility before retrying; never retry unrelated media failures.
          await hooks.wait(150);
          continue;
        }
        if (error.name !== 'NotAllowedError') throw error;
        if (!mutedAttempt) {
          // Follow Chrome's supported muted autoplay path without changing
          // browser permissions or pretending a script click is a user gesture.
          mutedAttempt = true; video.muted = true;
          hooks.notify('有声自动播放被浏览器拦截，正在改为静音启动');
          continue;
        }
        hooks.notify('静音启动仍被浏览器阻止：请手动点一次视频播放');
        for (let n = 0; n < 60; n++) {
          await hooks.wait(1000);
          await hooks.active();
          if (!video.paused && !video.ended) return;
        }
        throw new WatchError('等待手动启动播放超时');
      }
    }
  }
  async function pollHistory(read, accept, hooks) {
    // Read immediately and only wait when the site's asynchronous save is still pending.
    let record;
    for (let attempt = 0; attempt < 13; attempt++) {
      record = await read();
      if (accept(record)) return record;
      if (attempt < 12) await hooks.wait(200);
    }
    return record;
  }
  function continuousRateAccepted(before, after, mediaDelta) {
    // The native player saves at >30 media seconds, leaving an unsaved tail.
    const credit = Number(after) - Number(before);
    return mediaDelta >= 60 && credit >= Math.max(24, (mediaDelta - 35) * 0.8);
  }
  async function monitorContinuousVideo(video, hooks) {
    const now = hooks.now || Date.now;
    let rate = applyVideoRate(video, hooks.preferredRate || 16);
    let observed = 0, lastTime = video.currentTime, lastMotion = now();
    let seeking = false, replayCount = 0, insufficient = 0, lastFinishCheck = -Infinity;
    const observe = () => {
      const current = video.currentTime, delta = current - lastTime;
      if (!seeking && !video.seeking && delta > 0 && delta <= Math.max(4, video.playbackRate * 2)) { observed += delta; lastMotion = now(); }
      lastTime = current;
    };
    const onSeek = () => { seeking = true; lastTime = video.currentTime; };
    const onSeeked = () => { seeking = false; lastTime = video.currentTime; lastMotion = now(); };
    video.addEventListener('timeupdate', observe);
    video.addEventListener('seeking', onSeek);
    video.addEventListener('seeked', onSeeked);
    try {
      await hooks.active();
      // Begin playback while the first history query is in flight, rather than waiting for it.
      await hooks.start();
      lastMotion = now();
      let record = await hooks.read(), credit = Number(record.watched_duration || 0);
      let baseCredit = credit, baseObserved = observed, checkedObserved = observed, checkedAt = now();
      let unverifiedStart = video.currentTime;
      for (;;) {
        const visible = await hooks.active();
        if (visible === false) { lastTime = video.currentTime; lastMotion = now(); checkedAt = now(); continue; }
        if (video.error) throw new WatchError(`播放器错误：${video.error.message || video.error.code}`);
        if (video.ended) {
          video.pause();
          record = await pollHistory(hooks.read, r => r.historyExists && (Number(r.watched_duration) >= video.duration * 0.95 || Number(r.watched_duration) > credit + 0.25), hooks);
          credit = Number(record.watched_duration || 0);
          if (await hooks.finish()) { hooks.remember(rate); return; }
          if (++replayCount > 2) throw new WatchError('视频补播后服务器仍未确认完成');
          video.currentTime = 0; lastTime = 0; lastMotion = now();
          baseCredit = credit; baseObserved = observed; checkedObserved = observed; checkedAt = now(); unverifiedStart = 0; insufficient = 0;
        }
        if (Math.abs(video.playbackRate - rate) > 0.01) video.playbackRate = rate;
        if (video.paused) await hooks.start();
        hooks.notify(`${video.readyState < 3 && now() - lastMotion > 1500 ? '正在缓冲' : '连续播放'}；视频位置 ${video.currentTime.toFixed(1)} / ${video.duration.toFixed(1)} 秒；服务器累计 ${credit.toFixed(1)} 秒`, rate);
        await hooks.wait(250); observe();
        if (now() - lastMotion > 60000) throw new WatchError('视频连续 60 秒未推进');
        // All reads below run while the native player keeps playing and saving progress.
        if ((observed - checkedObserved >= 64 && now() - checkedAt >= 2000) || now() - checkedAt >= Math.max(8000, 75000 / rate)) {
          const sampleObserved = observed;
          record = await hooks.read(); credit = Number(record.watched_duration || 0);
          checkedObserved = observed; checkedAt = now();
          const windowMedia = sampleObserved - baseObserved;
          if (continuousRateAccepted(baseCredit, credit, windowMedia)) {
            hooks.remember(rate); insufficient = 0;
            // Keep a cumulative window for this rate. A short lag must not make a
            // server that credits only wall-clock time appear to support high speed.
            unverifiedStart = video.currentTime;
          } else if (windowMedia >= 60 && ++insufficient >= 2) {
            const index = RATES.indexOf(rate);
            if (index === RATES.length - 1) throw new WatchError(record.historyExists ? '连续两次后台核验服务器进度不足' : '正常播放后仍未建立观看历史');
            rate = applyVideoRate(video, RATES[index + 1]);
            // Only a confirmed recording problem triggers a corrective replay. No scheduled pauses.
            video.currentTime = Math.max(0, unverifiedStart); lastTime = video.currentTime;
            baseCredit = credit; baseObserved = observed; checkedObserved = observed; checkedAt = now(); insufficient = 0; lastMotion = now();
            hooks.notify(`服务器进度不足，降至 ${rate} 倍补播`, rate);
          }
          if (credit >= video.duration * 0.95 && now() - lastFinishCheck > 10000) {
            lastFinishCheck = now();
            if (await hooks.finish()) { video.pause(); hooks.remember(rate); return; }
          }
        }
      }
    } finally {
      video.removeEventListener('timeupdate', observe);
      video.removeEventListener('seeking', onSeek);
      video.removeEventListener('seeked', onSeeked);
    }
  }
  function allowOwnedTaskExit(job, runId, taskId, ticket, intentional = false) {
    if (intentional || !job || job.runId !== runId || ['stopped', 'complete'].includes(job.state)) return true;
    const task = job.tasks.find(task => task.id === taskId);
    return !task || task.ticket !== ticket || task.status !== 'running';
  }
  function classify(node) {
    const name = String(node.name || '').toLowerCase();
    const mime = String(node.mimetype || '').toLowerCase();
    if (Number(node.type) === 9 || mime.startsWith('video/') || /\.(mp4|webm|m4v|mov|m3u8)$/.test(name)) return 'video';
    if (mime.startsWith('audio/') || /\.(mp3|wav|m4a|aac|flac|ogg)$/.test(name)) return 'unsupported';
    if (/\.(pdf|pptx?|docx?|xlsx?|txt|rtf|odt|odp|ods|png|jpe?g|gif|webp)$/.test(name)) return 'document';
    return 'unsupported';
  }
  function eligibility(task, now = Date.now()) {
    if (Number.isFinite(Date.parse(task.start)) && Date.parse(task.start) > now) return '任务尚未开放';
    if (Number.isFinite(Date.parse(task.end)) && Date.parse(task.end) < now && !task.allowLate) return '任务已截止且不允许补交';
    return null;
  }
  function makeTasks(records, findNode, groupId) {
    const seen = new Set();
    return records.filter(r => Number(r.task_type) === 1 && (!r.group_id || String(r.group_id) === groupId)).map(r => {
      const node = plain(findNode(String(r.node_id))) || {};
      const id = String(r.task_id || r.id || '');
      if (!id || seen.has(id)) return null;
      seen.add(id);
      const task = {
        id, nodeId: String(r.node_id || node.id || ''),
        parentId: String(r.parent_id || node.parent_id || ''),
        quoteId: String(r.quote_id || node.quote_id || ''),
        assignId: String(r.assign_id || ''), name: String(node.name || r.name || r.node_id),
        kind: classify(node), start: r.start_time || '', end: r.end_time || '',
        allowLate: r.is_allow_after_submitted === true,
        minMinutes: Number(r.watch_min_minutes ?? node.watch_min_minutes) || 0,
        status: finished(r) || r._isFinish === true ? 'already' : 'pending',
        attempts: 0, note: '',
      };
      const reason = eligibility(task);
      if (task.status === 'pending' && (reason || task.kind === 'unsupported' || !task.nodeId || !task.parentId)) {
        task.status = 'skipped'; task.note = reason || '资源类型或目录结构暂不支持';
      }
      return task;
    }).filter(Boolean).sort((a, b) => natural(a.name, b.name) || natural(a.id, b.id));
  }
  function nextTasks(tasks, parallel) {
    const docs = tasks.filter(t => t.kind === 'document' && !FINALS.has(t.status));
    if (docs.length) {
      return docs.filter(t => t.status === 'pending').slice(0, Math.max(0, parallel - docs.filter(t => t.status === 'running').length));
    }
    if (tasks.some(t => t.status === 'running')) return [];
    const video = tasks.find(t => t.kind === 'video' && t.status === 'pending');
    return video ? [video] : [];
  }
  function documentConcurrency(parallel, capability) {
    return capability?.docsParallel === 'verified' ? parallel : Math.min(parallel, 2);
  }
  function applyResult(task, result) {
    if (result.state === 'success' && result.verified === true) {
      return { ...task, status: 'success', note: result.message || '服务器已确认完成' };
    }
    if (result.state === 'skipped') return { ...task, status: 'skipped', note: result.message };
    return { ...task, status: task.attempts < 2 ? 'pending' : 'failed', note: result.message || '未能核验完成' };
  }
  function rateAccepted(before, after, mediaDelta) {
    const credited = Number(after) - Number(before);
    return mediaDelta >= 28 && credited >= Math.max(3, Math.min(mediaDelta, 30) * 0.8);
  }
  function workerURL(groupId, runId, task) {
    const url = new URL(`/app/jx-web/mycourse/${encodeURIComponent(groupId)}/resource/${encodeURIComponent(task.parentId)}/${encodeURIComponent(task.nodeId)}`, 'https://whut.ai-augmented.com');
    url.hash = new URLSearchParams({ whut_watch: runId, task: task.id, ticket: task.ticket }).toString();
    return url.href;
  }
  function fibersFrom(element, limit = 90) {
    const key = element && Object.keys(element).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
    const out = [];
    for (let f = element?.[key], i = 0; f && i < limit; f = f.return, i++) out.push(f);
    return out;
  }
  function nativeGetFunction(value) {
    if (typeof value !== 'function') return false;
    const source = Function.prototype.toString.call(value);
    return /(?:\bmethod|["']method["'])\s*:\s*["']GET["']/.test(source)
      && /(?:\bheaders|["']headers["'])\s*:/.test(source)
      && /(?:\btimeout|["']timeout["'])\s*:/.test(source);
  }
  function findGetExport(namespace, preferred) {
    if (preferred && nativeGetFunction(namespace[preferred])) return preferred;
    const functions = new Map();
    for (const key of Object.keys(namespace)) {
      if (nativeGetFunction(namespace[key]) && !functions.has(namespace[key])) functions.set(namespace[key], key);
    }
    // An ambiguous module is not safe to guess. Aliases of the same function are OK.
    return functions.size === 1 ? [...functions.values()][0] : null;
  }
  function applicationModuleURL(value) {
    try {
      const url = new URL(value);
      return url.origin === 'https://whut.ai-augmented.com' && !url.username && !url.password && !url.hash
        && /^\/app\/jx-web\/js\/index-[^/]+\.js$/.test(url.pathname) ? url.href : null;
    } catch { return null; }
  }
  function harvest(doc, groupId) {
    for (const row of doc.querySelectorAll('tbody tr')) {
      const chain = fibersFrom(row);
      const pageProps = chain.map(f => f.memoizedProps).find(p => p && String(p.group_id) === groupId && Array.isArray(plain(p.tasks)) && p.nodes);
      if (pageProps) {
        const nodes = plain(pageProps.nodes);
        return makeTasks(plain(pageProps.tasks), id => nodes[id], groupId);
      }
      const table = chain.map(f => f.memoizedProps).find(p => p?.findNode && Array.isArray(p.dataSource));
      if (table) return makeTasks(table.dataSource, id => table.findNode(id), groupId);
    }
    throw new WatchError('任务列表尚未加载，或网站结构已变化；请打开“全部任务”页后重试。');
  }

  async function boot(options = {}) {
    const page = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
    if (page.top !== page || location.hostname !== 'whut.ai-augmented.com') return;
    if (!document.documentElement) await new Promise(resolve => {
      const observer = new MutationObserver(() => {
        if (document.documentElement) { observer.disconnect(); resolve(); }
      });
      observer.observe(document, { childList: true });
    });
    if (document.getElementById('whut-watch-host')) return;
    const route = location.pathname.match(/\/mycourse\/(\d+)(?:\/|$)/);
    if (!route) return;
    const groupId = route[1];
    const gm = typeof GM_getValue === 'function';
    const get = (key, fallback = null) => {
      if (gm) return GM_getValue(PREFIX + key, fallback);
      try { return JSON.parse(localStorage.getItem(PREFIX + key)) ?? fallback; } catch { return fallback; }
    };
    const put = (key, value) => {
      if (gm) GM_setValue(PREFIX + key, value);
      else localStorage.setItem(PREFIX + key, JSON.stringify(value));
    };
    const jobKey = `job:${groupId}`;
    const apiKey = `api:${groupId}`;
    const tabId = sessionStorage.getItem(PREFIX + 'tab') || uid();
    sessionStorage.setItem(PREFIX + 'tab', tabId);
    const token = new URLSearchParams(location.hash.slice(1));
    const isWorker = !!token.get('whut_watch');
    const handles = new Map();
    let job = null, held = false, release = null, apiPromise = null, busy = false, commandBusy = false;
    let wakeLock = null;
    const locks = page.navigator.locks;
    const statusKey = task => `worker:${groupId}:${task.ticket}`;
    const capKey = run => `capability:${groupId}:${run}`;

    const host = document.createElement('div');
    host.id = 'whut-watch-host'; document.documentElement.append(host);
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `<style>
      :host{all:initial;position:fixed;right:18px;bottom:18px;z-index:2147483646;font:13px/1.55 system-ui,-apple-system,"PingFang SC",sans-serif;color:#e7edf5}
      section{width:326px;max-height:72vh;overflow:auto;background:#162330;border:1px solid #395364;border-radius:14px;padding:16px;box-shadow:0 12px 40px #0005}
      h3{font-size:16px;margin:0 0 8px}p{margin:6px 0;overflow-wrap:anywhere}.muted{color:#aebfce;font-size:12px}
      .buttons{display:flex;flex-wrap:wrap;gap:7px;margin:10px 0}button{font:inherit;border:0;border-radius:7px;padding:6px 11px;color:#122431;background:#d9e5ed;cursor:pointer}
      button.primary{background:#75dfc0}button:disabled{opacity:.4;cursor:default}input[type=number]{width:42px;background:#263a4b;color:white;border:1px solid #647b8c;border-radius:4px;padding:3px}
      label{display:block;margin-top:6px}progress{width:100%;accent-color:#75dfc0}details{border-top:1px solid #395364;margin-top:10px;padding-top:8px}summary{cursor:pointer}
      li{margin:6px 0;overflow-wrap:anywhere}ul{padding-left:18px;max-height:150px;overflow:auto}#current{white-space:pre-line}.bad{color:#ffc28f}
    </style><section><h3>理工智课 <small style="font-size:11px">${VERSION}</small></h3>
    <p id="summary">${isWorker ? '任务标签正在连接控制面板…' : '文档并行 · 视频串行'}</p><progress id="progress" max="1" value="0"></progress>
    <p id="current" class="muted"></p><p id="notice" class="bad"></p>
    <div id="controller"><label>文档同时打开 <input id="parallel" type="number" min="1" max="8" value="4"> 个</label>
    <label><input id="direct" type="checkbox" checked> 优先验证底层进度写入</label>
    <p class="muted">底层验证会修改当前账号该视频的观看记录；只有服务器核验通过才计成功。</p>
    <div class="buttons"><button id="start" class="primary">开始</button><button id="pause">暂停</button><button id="resume">继续</button><button id="stop">停止</button><button id="export">导出结果</button></div></div>
    <details><summary>失败与跳过</summary><ul id="failures"></ul></details>
    <p class="muted">保留本控制页；视频需前台、电脑需保持唤醒。建议关闭开发者工具以免站点 debugger 暂停。</p></section>`;
    const ui = id => shadow.getElementById(id);
    if (isWorker) ui('controller').hidden = true;
    const show = message => { ui('notice').textContent = message; };

    async function acquireWakeLock() {
      try { if (document.visibilityState === 'visible' && !wakeLock && page.navigator.wakeLock) wakeLock = await page.navigator.wakeLock.request('screen'); }
      catch { /* Some browsers require a user gesture. The user is also told to keep the computer awake. */ }
      if (wakeLock) wakeLock.addEventListener('release', () => { wakeLock = null; }, { once: true });
    }
    function releaseWakeLock() { wakeLock?.release().catch(() => {}); wakeLock = null; }
    async function timed(promise, ms = 20000, text = '页面请求超时') {
      let timer;
      try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new WatchError(text)), ms); })]); }
      finally { clearTimeout(timer); }
    }
    function unpack(response) {
      if (response?.code === 401 || response?.code === 403 || /登录|unauthoriz|token.*expir/i.test(String(response?.message || ''))) throw new WatchError('登录已失效，请登录后继续', 'auth');
      if (!response || response.success !== true) throw new WatchError(response?.message || '网站未确认请求成功', 'task', response?.code);
      return response.data;
    }
    async function api() {
      if (apiPromise) return apiPromise;
      apiPromise = (async () => {
        // Import cached modules in the page's own realm. Minified function names are not stable.
        const scripts = [...(document.scripts || [])].map(s => applicationModuleURL(s.src)).filter(Boolean);
        const entryURL = scripts[0] || null;
        const resources = page.performance.getEntriesByType('resource').filter(e => e.initiatorType !== 'link')
          .sort((a, b) => (b.decodedBodySize || 0) - (a.decodedBodySize || 0)).map(e => applicationModuleURL(e.name)).filter(Boolean);
        const loaded = [...new Set([...resources, ...scripts])];
        const hint = get(jobKey)?.apiDescriptor || get(apiKey);
        const hintURL = applicationModuleURL(hint?.moduleURL);
        const trustedHint = hintURL && (loaded.includes(hintURL) || (entryURL && hint.entryURL === entryURL)) ? hint : null;
        const candidates = [...new Set([trustedHint?.moduleURL, ...loaded].filter(Boolean))];
        const deadline = Date.now() + 45000;
        for (const url of candidates.slice(0, 18)) {
          if (Date.now() >= deadline) break;
          let module;
          try { module = await timed(page.Function('url', 'return import(url)')(url), Math.min(10000, deadline - Date.now()), '网站接口模块加载超时'); }
          catch { continue; }
          const preferred = trustedHint?.moduleURL === url ? trustedHint.exportName : null;
          const getExport = findGetExport(module, preferred);
          if (!getExport) continue;
          const descriptor = { moduleURL: url, exportName: getExport, entryURL };
          put(apiKey, descriptor);
          return {
            descriptor,
            read: async (path, params = {}) => {
              // This API rejects unknown query fields. Use headers, not a cache-buster parameter.
              try { return unpack(await timed(module[getExport](API + path, params, { 'Cache-Control': 'no-cache' }, 15000))); }
              catch (error) {
                if (/401|403|unauthoriz|登录|token.*expir/i.test(errorText(error))) throw new WatchError('登录已失效，请登录后继续', 'auth');
                throw error;
              }
            },
          };
        }
        throw new WatchError('此任务页未能连接网站的进度查询方法；本次未开始写入进度。请停止队列、更新脚本并刷新全部任务页后重试。');
      })();
      apiPromise.catch(() => { apiPromise = null; });
      return apiPromise;
    }
    async function readStatus(task) {
      return (await api()).read('/resource/task/studentFinishInfo/v2', { group_id: groupId, node_id: task.nodeId, task_id: task.id });
    }
    async function readDuration(task) {
      if (!task.quoteId) throw new WatchError('视频资源编号缺失');
      return readMediaHistory((await api()).read, task.quoteId);
    }
    function headerInstance(task) {
      const starts = [...document.querySelectorAll('.xy_btn_task_normal,.xy_btn_task_finish,[class*="resource_header"],h5')];
      for (const element of starts) for (const f of fibersFrom(element)) {
        if (f.stateNode && typeof f.stateNode.handleTaskFinish === 'function' && String(f.memoizedProps?.node?.id) === task.nodeId) return f.stateNode;
      }
      return null;
    }
    function playerInstance() {
      for (const f of fibersFrom(document.querySelector('.prism-player'))) {
        if (f.stateNode && typeof f.stateNode.startUpdateDuration === 'function' && f.memoizedProps?.getProgress) return f.stateNode;
      }
      return null;
    }
    async function invokeFinish(task) {
      const instance = headerInstance(task);
      if (!instance) throw new WatchError('未找到该任务的原生完成入口');
      // This is the site's normal button handler, including deadline and timer checks.
      await timed(Promise.resolve(instance.handleTaskFinish(false)), 18000);
    }
    function dismissDurationNotice() {
      for (const modal of document.querySelectorAll('.ant-modal-content,.ant-modal-confirm')) {
        if (!modal.querySelector('.finish_task_info') && !/连续观看时间未达要求/.test(modal.textContent || '')) continue;
        const button = [...modal.querySelectorAll('button')].find(b => /^(知道了|我知道了|确定)$/.test(b.textContent.trim()));
        button?.click();
      }
    }
    function confirmFilePreview() {
      const hint = [...document.querySelectorAll('div,p,span')].find(e => /是否确认打开文件/.test(e.textContent || '') && ![...e.children].some(c => /是否确认打开文件/.test(c.textContent || '')));
      for (let p = hint, i = 0; p && i < 7; p = p.parentElement, i++) {
        if ((p.textContent || '').length > 1500) break;
        const button = [...p.querySelectorAll('button')].find(b => b.textContent.trim() === '确定');
        if (button) { button.click(); return true; }
      }
      return false;
    }
    function checkPage() {
      if (/\/login|\/sign.?in/i.test(location.pathname)) throw new WatchError('登录已失效，请登录后继续', 'auth');
      const dialogs = [...document.querySelectorAll('.ant-modal-content,[role="dialog"]')].map(e => e.textContent).join(' ');
      if (/验证码|人脸识别|请扫码|请重新登录|身份验证/.test(dialogs)) throw new WatchError('页面要求人工验证，请处理后继续', 'auth');
    }

    function render() {
      if (!job) return;
      const counts = job.tasks.reduce((a, t) => { a[t.status] = (a[t.status] || 0) + 1; return a; }, {});
      const totalDone = job.tasks.filter(t => FINALS.has(t.status)).length;
      const names = { running: '运行中', paused: '已暂停', stopped: '已停止', complete: '处理结束', verifying: '正在最终核验' };
      ui('summary').textContent = `${names[job.state] || job.state} · 本轮成功 ${counts.success || 0} · 原已完成 ${counts.already || 0} · 失败 ${counts.failed || 0} · 跳过 ${counts.skipped || 0}`;
      ui('progress').max = job.tasks.length || 1; ui('progress').value = totalDone;
      ui('current').textContent = job.tasks.filter(t => t.status === 'running').map(t => {
        const state = get(statusKey(t));
        return `${t.kind === 'video' ? '视频' : '文档'}：${t.name}\n${state?.message || '正在打开任务…'}${state?.rate ? ` · ${state.rate} 倍` : ''}`;
      }).join('\n');
      if (held && shadow.activeElement !== ui('parallel')) ui('parallel').value = String(job.parallel);
      if (held) ui('direct').checked = job.direct;
      ui('start').disabled = ['running', 'verifying'].includes(job.state);
      ui('pause').disabled = !['running', 'verifying'].includes(job.state);
      ui('resume').disabled = held ? !['paused', 'stopped'].includes(job.state) : job.state === 'complete';
      ui('stop').disabled = ['complete', 'stopped'].includes(job.state);
      const list = ui('failures'); list.replaceChildren();
      for (const task of job.tasks.filter(t => ['failed', 'skipped'].includes(t.status))) {
        const li = document.createElement('li'); li.textContent = `${task.name}：${task.note}`; list.append(li);
      }
      if (job.message) show(job.message);
    }
    function save() { job.heartbeat = Date.now(); put(jobKey, job); render(); }
    async function withControllerLock(action) {
      if (held) return action();
      if (!locks) throw new WatchError('此浏览器不支持跨标签独占控制，请使用当前版本 Chrome。');
      let resolveStarted, rejectStarted;
      const started = new Promise((resolve, reject) => { resolveStarted = resolve; rejectStarted = reject; });
      locks.request(`${PREFIX}controller:${groupId}`, { ifAvailable: true }, async lock => {
        if (!lock) { rejectStarted(new WatchError('另一控制页正在运行本课程，请在原控制页操作。')); return; }
        held = true;
        try {
          const untilRelease = new Promise(resolve => { release = resolve; });
          await action(); resolveStarted(); await untilRelease;
        } catch (error) { rejectStarted(error); }
        finally { held = false; release = null; }
      }).catch(rejectStarted);
      return started;
    }
    async function freshTasks() {
      const until = Date.now() + 60000;
      while (Date.now() < until) {
        checkPage();
        try { const result = harvest(document, groupId); if (result.length) return result; } catch { /* Await app rendering. */ }
        await sleep(500);
      }
      throw new WatchError('60 秒内未加载完整任务列表，请打开“全部任务”并清除筛选后重试。');
    }
    async function start() {
      if (!location.pathname.startsWith(`/app/jx-web/mycourse/${groupId}/task`)) throw new WatchError('请先打开当前课程的“全部任务”页；切换课程后请刷新。');
      await withControllerLock(async () => {
        const old = get(jobKey);
        if (old && ['running', 'verifying'].includes(old.state) && old.owner !== tabId && Date.now() - old.heartbeat < 15000) throw new WatchError('另一个控制页仍在运行');
        show('正在读取完整任务列表并核对服务器状态…');
        const tasks = await freshTasks();
        // Initial server reads also catch a stale task list before opening workers.
        for (let offset = 0; offset < tasks.length; offset += 4) {
          await Promise.all(tasks.slice(offset, offset + 4).map(async task => {
            const status = await readStatus(task);
            if (finished(status)) task.status = 'already';
            else if (task.status === 'already') {
              task.note = eligibility(task) || (task.kind === 'unsupported' ? '资源类型暂不支持' : '');
              task.status = task.note ? 'skipped' : 'pending';
            }
          }));
        }
        job = { version: VERSION, runId: uid(), owner: tabId, groupId, state: 'running', createdAt: Date.now(),
          parallel: Math.min(8, Math.max(1, Number(ui('parallel').value) || 4)), direct: ui('direct').checked,
          tasks, apiDescriptor: (await api()).descriptor, message: '', heartbeat: Date.now() };
        put(capKey(job.runId), { direct: 'unknown', docsParallel: 'unverified' });
        save(); await acquireWakeLock();
      });
    }
    async function resume() {
      await withControllerLock(async () => {
        job = get(jobKey);
        if (!job || job.state === 'complete') throw new WatchError('没有可以继续的队列');
        job.apiDescriptor = (await api()).descriptor;
        job.owner = tabId;
        for (const task of job.tasks.filter(t => t.status === 'running')) {
          const worker = get(statusKey(task));
          if (worker?.state === 'success' && worker.verified) Object.assign(task, applyResult(task, worker));
          else if (!worker || Date.now() - worker.at > 45000 || ['failed', 'cancelled', 'auth'].includes(worker.state)) {
            try { handles.get(task.ticket)?.close(); } catch { /* Old owner may have opened the tab. */ }
            handles.delete(task.ticket); task.status = 'pending';
            if (worker?.state !== 'failed') task.attempts = Math.max(0, task.attempts - 1);
          }
        }
        job.state = 'running'; job.message = ''; save(); await acquireWakeLock();
      });
    }
    function control(state) {
      const current = get(jobKey);
      if (!current) return;
      if (current.owner !== tabId && !held) { show('请在拥有队列的控制页操作，或先点击“继续”接管。'); return; }
      job = current; job.state = state; job.message = state === 'paused' ? '视频已请求暂停；已打开文档可能继续计时。' : '已停止，保留结果；可继续尚未完成的任务。'; save();
      if (state === 'stopped') {
        for (const handle of handles.values()) try { handle.close(); } catch { /* Worker can also close itself. */ }
        handles.clear();
        for (const task of job.tasks.filter(t => t.status === 'running')) { task.status = 'pending'; task.attempts = Math.max(0, task.attempts - 1); }
        save(); release?.();
      }
      releaseWakeLock();
    }
    function openWorker(task) {
      task.status = 'running'; task.attempts++; task.ticket = uid(); task.openedAt = Date.now();
      put(statusKey(task), { state: 'loading', at: Date.now(), message: '等待任务页面加载' });
      save();
      const url = workerURL(groupId, job.runId, task);
      let handle;
      if (typeof GM_openInTab === 'function') handle = GM_openInTab(url, { active: task.kind === 'video', insert: true, setParent: true });
      else if (options.allowBrowserFallback) handle = page.open(url, '_blank');
      else throw new WatchError('需要安装到 Tampermonkey 后才能自动管理任务标签。');
      if (!handle) throw new WatchError('任务标签未能打开，请检查浏览器弹窗设置');
      handles.set(task.ticket, handle);
    }
    async function finalAudit() {
      job.state = 'verifying'; job.message = '正在重新核对全部自主观看任务的服务器状态…'; save();
      const runId = job.runId;
      for (let offset = 0; offset < job.tasks.length; offset += 4) {
        const control = get(jobKey);
        if (control?.runId !== runId || control.state !== 'verifying') { job = control; return; }
        await Promise.all(job.tasks.slice(offset, offset + 4).map(async task => {
          try {
            const status = await readStatus(task);
            if (finished(status)) { if (task.status !== 'already') task.status = 'success'; task.note = '最终服务器核验通过'; }
            else if (task.status === 'success' || task.status === 'already') { task.status = 'failed'; task.note = '最终服务器状态未确认完成'; }
          } catch (error) {
            if (error.kind === 'auth') throw error;
            if (task.status === 'success' || task.status === 'already') { task.status = 'failed'; task.note = '最终核验失败：' + errorText(error); }
          }
        }));
        const afterRead = get(jobKey);
        if (afterRead?.runId !== runId || afterRead.state !== 'verifying') { job = afterRead; render(); return; }
        save();
      }
      job.state = 'complete'; job.message = '本轮处理结束。成功项均已重新查询服务器；失败和跳过项请查看清单。'; save();
      releaseWakeLock(); release?.();
    }
    async function tick() {
      if (busy || !held) { if (!held) { job = get(jobKey); render(); } return; }
      busy = true;
      try {
        job = get(jobKey); if (!job || job.owner !== tabId) return;
        if (!['running', 'paused'].includes(job.state)) return;
        for (const task of job.tasks.filter(t => t.status === 'running')) {
          const worker = get(statusKey(task));
          if (worker?.state === 'auth') { job.state = 'paused'; job.message = worker.message; save(); return; }
          if (worker?.state === 'cancelled') {
            job.state = 'paused'; job.message = worker.message || '任务已中断，请点击继续'; save(); return;
          }
          if (['success', 'failed', 'skipped'].includes(worker?.state)) {
            const handle = handles.get(task.ticket); try { handle?.close(); } catch { /* Already closed. */ }
            handles.delete(task.ticket);
            Object.assign(task, applyResult(task, worker));
            if (task.status === 'success') task.completedAt = Date.now();
          } else if (handles.get(task.ticket)?.closed) Object.assign(task, applyResult(task, { message: '任务标签被关闭' }));
          else if (Date.now() - (worker?.at || task.openedAt) > 65000) {
            if (worker?.state === 'loading') {
              try { handles.get(task.ticket)?.close(); } catch { /* Already closed. */ }
              Object.assign(task, applyResult(task, { message: '60 秒内任务页面未能加载' }));
            } else {
              job.state = 'paused'; job.message = '任务标签失去响应，可能已跳转登录页。请检查后点击继续。'; save(); return;
            }
          }
        }
        if (job.state === 'running') {
          const capability = get(capKey(job.runId), {});
          if (capability.docsParallel !== 'verified') {
            const completed = job.tasks.filter(t => t.kind === 'document' && t.status === 'success' && t.completedAt);
            const overlap = completed.some((a, index) => completed.slice(index + 1).some(b => a.openedAt < b.completedAt && b.openedAt < a.completedAt));
            if (overlap) { capability.docsParallel = 'verified'; capability.docsNote = '两个重叠运行文档均通过服务器完成核验'; put(capKey(job.runId), capability); }
          }
          const parallel = documentConcurrency(job.parallel, capability);
          for (const task of nextTasks(job.tasks, parallel)) {
            const reason = eligibility(task);
            if (reason) { task.status = 'skipped'; task.note = reason; continue; }
            try { openWorker(task); }
            catch (error) { Object.assign(task, applyResult(task, { message: errorText(error) })); }
          }
        }
        save();
        if (job.state === 'running' && job.tasks.every(t => FINALS.has(t.status))) await finalAudit();
      } catch (error) {
        job = get(jobKey);
        if (job) { job.state = 'paused'; job.message = errorText(error); save(); }
        else show(errorText(error));
      } finally { busy = false; }
    }

    async function workerMain() {
      const runId = token.get('whut_watch'), id = token.get('task'), ticket = token.get('ticket');
      let task = get(jobKey)?.tasks.find(t => t.id === id && t.ticket === ticket);
      if (!task || get(jobKey).runId !== runId || task.status !== 'running') {
        ui('summary').textContent = '任务标签已失效'; show('请从“全部任务”的控制面板重新开始。'); return;
      }
      let message = '等待资源加载', rate = null, terminating = false, ownerLost = false, controllerCheckedAt = 0, intentionalExit = false;
      // Only matching, script-owned read-only tasks reach here. Preserve normal leave warnings
      // while a task is running, but don't let them block an intentional verified exit or stop.
      page.addEventListener('beforeunload', event => {
        if (allowOwnedTaskExit(get(jobKey), runId, id, ticket, intentionalExit)) event.stopImmediatePropagation();
      }, { capture: true });
      const previous = get(statusKey(task), {});
      let checkpoint = previous.checkpoint || null;
      const report = (state = 'working', extra = {}) => {
        put(statusKey(task), { state, at: Date.now(), message, rate, checkpoint, ...extra });
        ui('summary').textContent = task.name; ui('current').textContent = message;
      };
      message = '任务标签已连接，等待网站播放器加载'; report();
      const currentControl = () => {
        const j = get(jobKey);
        const t = j?.tasks.find(t => t.id === task.id);
        if (j?.runId !== runId || t?.ticket !== ticket || t.status !== 'running' || ['stopped', 'complete'].includes(j.state)) throw new WatchError('队列已停止或任务已被重新分配', 'cancelled');
        if (!location.pathname.endsWith(`/resource/${task.parentId}/${task.nodeId}`)) throw new WatchError('任务标签已离开原资源，请从控制页继续', 'cancelled');
        return j;
      };
      async function gate() {
        checkPage();
        for (;;) {
          const control = currentControl();
          // Chrome may throttle a hidden controller to one timer wake-up per minute.
          // A held Web Lock proves that it is still alive, avoiding a false cancellation.
          if (Date.now() - control.heartbeat > 45000 && Date.now() - controllerCheckedAt > 10000) {
            const snapshot = await timed(locks.query(), 5000, '无法确认控制页是否仍在运行');
            if (!snapshot.held.some(lock => lock.name === `${PREFIX}controller:${groupId}`)) {
              document.querySelector('video')?.pause();
              throw new WatchError('控制页已关闭，请返回全部任务页继续', 'cancelled');
            }
            controllerCheckedAt = Date.now();
          }
          if (control.state !== 'paused') return control;
          document.querySelector('video')?.pause();
          message = '队列暂停；文档可能继续计时'; report(); await sleep(1000);
        }
      }
      async function wait(ms) {
        let remaining = ms;
        while (remaining > 0) { await gate(); const step = Math.min(remaining, 1000); await sleep(step); remaining -= step; }
        await gate();
      }
      async function verifyFinish(waitMs = 12000) {
        await gate(); await invokeFinish(task);
        const deadline = Date.now() + waitMs;
        while (Date.now() < deadline) {
          await gate();
          if (finished(await readStatus(task))) {
            await wait(200);
            return finished(await readStatus(task));
          }
          await wait(250);
        }
        dismissDurationNotice(); return false;
      }
      async function videoReady() {
        const deadline = Date.now() + 60000;
        let startedForMetadata = false;
        while (Date.now() < deadline) {
          await gate();
          const video = document.querySelector('video');
          if (video?.error) throw new WatchError(`播放器错误：${video.error.message || video.error.code}`);
          const instance = playerInstance();
          if (video && instance && headerInstance(task)) {
            if (video.readyState >= 1 && Number.isFinite(video.duration) && video.duration > 0) return video;
            // A lazy SDK may not request metadata until its own play entry runs.
            // Do not wait for metadata before triggering that entry.
            if (!startedForMetadata) {
              startedForMetadata = true;
              message = '播放器已出现，正在启动原生播放器以加载视频信息'; report();
              await startPlayback(video);
              continue;
            }
          }
          message = !video ? '网站尚未创建视频元素，等待页面加载' : !instance ? '视频元素已出现，等待原生播放器实例' : '等待原任务入口或视频信息'; report();
          await wait(150);
        }
        throw new WatchError('60 秒内视频播放器未准备好');
      }
      async function directAttempt(video) {
        const capability = get(capKey(runId), { direct: 'unknown' });
        const onceKey = `direct-once:${groupId}:${runId}:${task.id}`;
        if (checkpoint?.stage === 'direct-reload') {
          message = '刷新后核验底层写入与任务状态'; report();
          const saved = await readDuration(task);
          const valid = Number(saved.watched_duration) + 0.5 >= checkpoint.duration && (finished(await readStatus(task)) || await verifyFinish());
          checkpoint = null;
          put(capKey(runId), { ...capability, direct: valid ? 'verified' : 'disabled', note: valid ? '刷新后服务器核验通过' : '刷新后未确认完成，已回退正常播放' });
          report(); return valid;
        }
        if (!currentControl().direct || capability.direct === 'disabled') return false;
        if (get(onceKey, false)) return false;
        try {
          message = '正在验证底层进度保存（本任务只尝试一次）'; report();
          const record = await readDuration(task);
          if (!record.historyExists) { message = '观看历史尚未建立，继续正常播放并等待网站保存'; report(); return false; }
          const instance = playerInstance();
          if (!instance || String(instance.props.quote_id) !== task.quoteId) throw new WatchError('播放器资源编号不一致');
          const remaining = Math.max(4, video.duration - Number(record.watched_duration || 0) + 0.1);
          if (!Number.isFinite(remaining) || remaining > 86400) throw new WatchError('视频时长不合理');
          put(onceKey, true);
          const old = instance.watched_duration;
          instance.watched_duration = remaining;
          try { instance.startUpdateDuration(task.quoteId, instance.props.video_id, video.duration, video.duration); }
          finally { if (instance.watched_duration === remaining) instance.watched_duration = old; }
          let saved = null;
          for (let i = 0; i < 10; i++) {
            saved = await readDuration(task);
            if (Number(saved.watched_duration) + 0.5 >= video.duration) break;
            if (i < 9) await wait(i < 4 ? 200 : 1500);
          }
          if (!(Number(saved?.watched_duration) + 0.5 >= video.duration) || !await verifyFinish()) throw new WatchError('服务器未确认底层写入或任务完成');
          checkpoint = { stage: 'direct-reload', duration: video.duration }; message = '写入和完成检查通过，正在刷新核验持久状态'; report();
          terminating = true; intentionalExit = true; location.reload();
          return null;
        } catch (error) {
          if (['auth', 'cancelled'].includes(error.kind)) throw error;
          put(capKey(runId), { ...capability, direct: 'disabled', note: errorText(error) });
          checkpoint = null; message = '底层方式未通过，改用正常倍速播放'; report(); return false;
        }
      }
      async function foregroundVideo(video) {
        await gate();
        while (document.visibilityState !== 'visible') {
          video.pause(); message = '请切回此视频标签，等待网站建立观看历史'; report(); await wait(1000);
        }
      }
      async function startPlayback(video) {
        // Script-owned workers start muted before invoking the SDK. This avoids
        // a rejected, unreturned play promise inside Aliplayer's own play().
        video.muted = true;
        await startVideoPlayback(video, {
          active: () => foregroundVideo(video), wait,
          player: () => playerInstance()?.player,
          play: () => timed(video.play(), 15000, '播放器启动超过 15 秒，可能仍在缓冲或页面已中断'),
          notify: text => { message = text; report(); },
        });
      }
      async function playVideo(video) {
        const cap = get(capKey(runId), {});
        await monitorContinuousVideo(video, {
          preferredRate: cap.rate || 16, read: () => readDuration(task), wait,
          active: async () => { const before = Date.now(); await foregroundVideo(video); await acquireWakeLock(); return Date.now() - before < 1000; },
          start: () => startPlayback(video), finish: () => verifyFinish(),
          notify: (text, value) => { message = text; rate = value; report(); },
          remember: value => put(capKey(runId), { ...get(capKey(runId), {}), rate: value, rateVerified: true }),
        });
      }
      async function runDocument() {
        let readyAt = Date.now(), lastActivity = Date.now(), lastAttempt = 0, lastText = '', attempts = 0;
        const loadingDeadline = Date.now() + 60000;
        while (!headerInstance(task)) {
          await gate(); if (Date.now() > loadingDeadline) throw new WatchError('60 秒内文档页面未加载'); await wait(500);
        }
        confirmFilePreview(); readyAt = Date.now();
        const required = task.minMinutes > 0 ? task.minMinutes * 60000 + 2500 : 0;
        for (;;) {
          await gate(); confirmFilePreview();
          const remaining = required - (Date.now() - readyAt);
          const localTimer = document.querySelector('.count_down,[class*="countdown"],[class*="count_down"]');
          const timerText = localTimer?.textContent.trim() || '';
          if (timerText && timerText !== lastText) { lastText = timerText; lastActivity = Date.now(); }
          if (remaining > 0) {
            message = `等待网站连续观看要求，至少还需 ${Math.ceil(remaining / 1000)} 秒`; report(); await wait(1000); continue;
          }
          if (attempts === 0 || Date.now() - lastAttempt > 10000) {
            message = '原观看时长已满足，正在操作原完成入口并查询服务器'; report();
            attempts++; if (await verifyFinish(8000)) return;
            dismissDurationNotice(); lastAttempt = Date.now();
          }
          if (required && Date.now() - readyAt > required + 60000) throw new WatchError('文档计时结束后 60 秒仍未确认完成');
          if (!required && Date.now() - readyAt > 600000 && (!lastText || Date.now() - lastActivity > 600000)) throw new WatchError('文档 10 分钟无有效进度变化');
          if (!required && Date.now() - readyAt > 660000) throw new WatchError('无法确认文档计时结束条件');
          message = timerText ? `等待原页面：${timerText}` : '等待网站确认文档完成'; report(); await wait(1000);
        }
      }
      const heartbeat = setInterval(() => {
        if (terminating) return;
        try { if (currentControl().state === 'paused') document.querySelector('video')?.pause(); report(); }
        catch { ownerLost = true; document.querySelector('video')?.pause(); }
      }, 2000);
      try {
        await locks.request(`${PREFIX}task:${groupId}:${task.id}`, { ifAvailable: true }, async lock => {
          if (!lock) throw new WatchError('该任务已有一个标签在处理');
          const run = async () => {
            await gate();
            if (task.kind === 'document') {
              if (finished(await readStatus(task))) return;
              await runDocument();
            }
            else {
              // Overlap page readiness with the server check instead of waiting for them serially.
              const ready = videoReady().then(video => ({ video }), error => ({ error }));
              if (checkpoint?.stage !== 'direct-reload' && finished(await readStatus(task))) return;
              const result = await ready;
              if (result.error) throw result.error;
              const video = result.video;
              const capability = get(capKey(runId), {});
              const wantsDirect = currentControl().direct && capability.direct !== 'disabled';
              if (checkpoint?.stage !== 'direct-reload' && wantsDirect) await initializeVideoHistory(video, () => readDuration(task), {
                active: () => foregroundVideo(video), start: () => startPlayback(video), wait,
                preferredRate: capability.rate || 16,
                notify: text => { message = text; report(); },
              });
              const direct = await directAttempt(video);
              if (direct === null) return;
              if (!direct) await playVideo(video);
            }
            if (!terminating && !finished(await readStatus(task))) throw new WatchError('服务器最终状态未确认完成');
          };
          if (task.kind === 'video') await locks.request(`${PREFIX}video`, { ifAvailable: true }, async lock => {
            if (!lock) throw new WatchError('另一个视频正在处理'); await run();
          });
          else await run();
        });
        if (!terminating) { message = '服务器已确认完成'; report('success', { verified: true }); }
      } catch (error) {
        document.querySelector('video')?.pause();
        message = errorText(error);
        report(error.kind === 'auth' ? 'auth' : error.kind === 'cancelled' ? 'cancelled' : 'failed', { verified: false });
        show(message);
      } finally {
        clearInterval(heartbeat); releaseWakeLock();
        if (!terminating && (ownerLost || get(statusKey(task))?.state !== 'auth')) {
          intentionalExit = true;
          await sleep(1000);
          // Only pages carrying this run's matching task ticket reach this branch.
          page.close();
        }
      }
    }

    if (isWorker) {
      if (!locks) { show('浏览器不支持跨标签独占控制'); return; }
      await workerMain(); return;
    }
    job = get(jobKey);
    if (job) { ui('parallel').value = String(job.parallel); ui('direct').checked = job.direct; render(); }
    if (job && ['running', 'verifying'].includes(job.state)) show('检测到已有队列。点击“继续”接管；不会自动重复开始。');
    const click = (id, handler) => ui(id).addEventListener('click', async () => {
      if (['start', 'resume'].includes(id) && commandBusy) return;
      if (['start', 'resume'].includes(id)) commandBusy = true;
      try { await handler(); } catch (error) { show(errorText(error)); }
      finally { if (['start', 'resume'].includes(id)) commandBusy = false; }
    });
    click('start', start); click('pause', () => control('paused')); click('resume', resume); click('stop', () => control('stopped'));
    ui('parallel').addEventListener('change', () => {
      if (!held || !job) return;
      job.parallel = Math.min(8, Math.max(1, Number(ui('parallel').value) || 4)); save();
    });
    ui('direct').addEventListener('change', () => { if (held && job) { job.direct = ui('direct').checked; save(); } });
    click('export', () => {
      const data = get(jobKey); if (!data) throw new WatchError('还没有运行结果');
      const report = { version: VERSION, course: groupId, state: data.state, createdAt: data.createdAt, capabilities: get(capKey(data.runId)),
        tasks: data.tasks.map(({ id, name, kind, status, attempts, note }) => ({ id, name, kind, status, attempts, note })) };
      const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = `自主观看结果-${groupId}.json`; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 5000);
    });
    const ticker = setInterval(tick, 1500);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && held && job?.state === 'running') acquireWakeLock(); });
    page.addEventListener('pagehide', () => { clearInterval(ticker); releaseWakeLock(); release?.(); }, { once: true });
    return { harvest: () => harvest(document, groupId), stop: () => control('stopped') };
  }
  return { VERSION, WatchError, readMediaHistory, initializeVideoHistory, applyVideoRate, startVideoPlayback, pollHistory, continuousRateAccepted, monitorContinuousVideo, allowOwnedTaskExit, classify, finished, eligibility, makeTasks, nextTasks, documentConcurrency, applyResult, rateAccepted, workerURL, fibersFrom, nativeGetFunction, findGetExport, applicationModuleURL, harvest, boot };
});
