'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const C = require('./理工智课1.1.user.js');

test('课程任务按字符串标识去重，视频和文档自然排序，排除非自主观看', () => {
  const ids = ['9000000000000000003', '9000000000000000004', '9000000000000000005'];
  const records = ids.map((id, i) => ({ task_id: id, node_id: id, parent_id: 'folder', group_id: '42', task_type: 1, watch_min_minutes: 2 }));
  const nodes = Object.fromEntries(ids.map((id, i) => [id, { name: ['10.1.mp4', '2.1.pptx', '2.2.mp4'][i], type: i === 1 ? 6 : 9 }]));
  const tasks = C.makeTasks([...records, records[0], { ...records[0], task_type: 4 }, { ...records[0], task_id: 'other', group_id: '43' }], id => nodes[id], '42');
  assert.deepEqual(tasks.map(t => t.name), ['2.1.pptx', '2.2.mp4', '10.1.mp4']);
  assert.equal(tasks.length, 3);
  assert.equal(new Set(tasks.map(t => t.id)).size, 3);
  assert.equal(tasks[0].minMinutes, 2);
  assert.equal(tasks[0].id, ids[1]);
});

test('仅认可服务器明确的完成字段，不能把本地百分比或字符串当作完成', () => {
  for (const value of [{ finished: false }, { finish_progress: 100 }, { finished: 'false' }, { finished: 'true' }, null, {}]) assert.equal(C.finished(value), false);
  assert.equal(C.finished({ finished: true }), true);
  assert.equal(C.finished({ finish: 2 }), true);
});

test('音频、压缩包和未知资源不会误入文档计时队列', () => {
  assert.equal(C.classify({ name: 'lecture.MP4' }), 'video');
  assert.equal(C.classify({ type: 9, name: '无扩展名' }), 'video');
  assert.equal(C.classify({ name: 'notes.PDF' }), 'document');
  assert.equal(C.classify({ name: 'slides.pptx' }), 'document');
  assert.equal(C.classify({ name: 'notes.pptx', mimetype: 'audio/mpeg' }), 'unsupported');
  assert.equal(C.classify({ name: 'a.mp3' }), 'unsupported');
  assert.equal(C.classify({ name: 'archive.zip', type: 6 }), 'unsupported');
});

test('未开放、已截止与允许补交的边界', () => {
  const now = Date.parse('2026-10-28T08:00:00Z');
  assert.match(C.eligibility({ start: '2026-10-29T00:00:00Z' }, now), /尚未开放/);
  assert.match(C.eligibility({ end: '2026-10-27T00:00:00Z' }, now), /截止/);
  assert.equal(C.eligibility({ end: '2026-10-27T00:00:00Z', allowLate: true }, now), null);
  assert.equal(C.eligibility({ start: '', end: '' }, now), null);
});

test('已完成和不支持的任务不会调度，原始输入不被修改', () => {
  const input = [{ task_id: '1', task_type: 1, node_id: '1', parent_id: 'p', _isFinish: true }, { task_id: '2', task_type: 1, node_id: '2', parent_id: 'p' }];
  const tasks = C.makeTasks(input, id => ({ name: id === '1' ? 'a.mp4' : 'a.zip' }), '42');
  assert.deepEqual(tasks.map(t => t.status), ['already', 'skipped']);
  assert.deepEqual(C.nextTasks(tasks, 4), []);
  assert.equal(input[0].status, undefined);
});

test('文档先于视频，并发补位不超限，最后一个文档运行时不能启动视频', () => {
  const tasks = [
    { id: 'v1', kind: 'video', status: 'pending' },
    ...Array.from({ length: 7 }, (_, n) => ({ id: `d${n}`, kind: 'document', status: 'pending' })),
    { id: 'v2', kind: 'video', status: 'pending' },
  ];
  const first = C.nextTasks(tasks, 4);
  assert.equal(first.length, 4);
  first.forEach(t => { t.status = 'running'; });
  assert.deepEqual(C.nextTasks(tasks, 4), []);
  first[0].status = 'success';
  assert.equal(C.nextTasks(tasks, 4).length, 1);
  tasks.filter(t => t.kind === 'document').forEach(t => { t.status = 'success'; });
  tasks[3].status = 'running';
  assert.deepEqual(C.nextTasks(tasks, 4), []);
  tasks[3].status = 'success';
  assert.deepEqual(C.nextTasks(tasks, 4).map(t => t.id), ['v1']);
  tasks[0].status = 'running';
  assert.deepEqual(C.nextTasks(tasks, 4), []);
  tasks[0].status = 'success';
  assert.deepEqual(C.nextTasks(tasks, 4).map(t => t.id), ['v2']);
});

test('降低文档并发不关闭已有文档，也不会新增超额任务', () => {
  const tasks = Array.from({ length: 8 }, (_, n) => ({ kind: 'document', status: n < 4 ? 'running' : 'pending' }));
  assert.deepEqual(C.nextTasks(tasks, 1), []);
  assert.equal(tasks.filter(t => t.status === 'running').length, 4);
  assert.equal(C.nextTasks(tasks, 8).length, 4);
});

test('首批最多两个文档并行，服务器核验后才提升到用户设置的并发数', () => {
  assert.equal(C.documentConcurrency(4, { docsParallel: 'unverified' }), 2);
  assert.equal(C.documentConcurrency(4, { docsParallel: 'verified' }), 4);
  assert.equal(C.documentConcurrency(8, { docsParallel: 'verified' }), 8);
  assert.equal(C.documentConcurrency(1, { docsParallel: 'unverified' }), 1);
});

test('一次失败重试、两次失败终止；成功必须有服务器核验标志', () => {
  const first = { id: '1', status: 'running', attempts: 1 };
  assert.equal(C.applyResult(first, { state: 'failed', message: 'timeout' }).status, 'pending');
  assert.equal(C.applyResult({ ...first, attempts: 2 }, { state: 'failed' }).status, 'failed');
  assert.equal(C.applyResult(first, { state: 'success' }).status, 'pending');
  assert.equal(C.applyResult(first, { state: 'success', verified: true }).status, 'success');
  assert.equal(C.applyResult(first, { state: 'skipped', message: '未开放' }).status, 'skipped');
});

test('模拟混合队列完整排空，重试任务不阻塞后续，最多一个视频', () => {
  let tasks = [
    ...Array.from({ length: 15 }, (_, n) => ({ id: `d${n}`, kind: 'document', status: 'pending', attempts: 0 })),
    ...Array.from({ length: 25 }, (_, n) => ({ id: `v${n}`, kind: 'video', status: 'pending', attempts: 0 })),
  ];
  const opened = [];
  for (let cycle = 0; cycle < 100; cycle++) {
    for (const task of C.nextTasks(tasks, 4)) { task.status = 'running'; task.attempts++; opened.push(task.id); }
    const running = tasks.filter(t => t.status === 'running');
    assert.ok(running.filter(t => t.kind === 'video').length <= 1);
    assert.ok(!running.some(t => t.kind === 'video') || !tasks.some(t => t.kind === 'document' && ['running', 'pending'].includes(t.status)));
    assert.ok(running.filter(t => t.kind === 'document').length <= 4);
    if (!running.length) break;
    tasks = tasks.map(t => t.status !== 'running' ? t : C.applyResult(t, t.id === 'd0' ? { state: 'failed' } : { state: 'success', verified: true }));
  }
  assert.equal(tasks.filter(t => t.status === 'success').length, 39);
  assert.equal(tasks.find(t => t.id === 'd0').status, 'failed');
  assert.equal(opened.filter(id => id === 'd0').length, 2);
  assert.equal(opened.filter(id => id === 'v0').length, 1);
});

test('倍速必须有足够实际播放区间和服务器增量；只计墙钟时长不认可高倍速', () => {
  assert.equal(C.rateAccepted(100, 132, 32), true);
  assert.equal(C.rateAccepted(100, 102, 32), false);
  assert.equal(C.rateAccepted(100, 100, 32), false);
  assert.equal(C.rateAccepted(100, 110, 5), false);
  assert.equal(C.rateAccepted(100, NaN, 32), false);
});

test('任务标签标记只包含当前课程、任务与运行票据，没有账号凭证', () => {
  const url = new URL(C.workerURL('9000000000000000001', 'run-1', { parentId: 'p', nodeId: 'n', id: 'task-1', ticket: 'ticket-1' }));
  assert.equal(url.origin, 'https://whut.ai-augmented.com');
  assert.equal(url.pathname, '/app/jx-web/mycourse/9000000000000000001/resource/p/n');
  assert.equal(new URLSearchParams(url.hash.slice(1)).get('ticket'), 'ticket-1');
  assert.equal(url.search, '');
});

test('React 全量任务入口优先于当前分页，即使第一页只有一个任务', () => {
  const page = { memoizedProps: { group_id: '42', tasks: [
    { id: '1', task_type: 1, node_id: 'n1', parent_id: 'p' },
    { id: '2', task_type: 1, node_id: 'n2', parent_id: 'p' },
  ], nodes: { n1: { name: '1.mp4' }, n2: { name: '2.pptx' } } } };
  const row = { '__reactFiber$fixture': { memoizedProps: {}, return: page } };
  const doc = { querySelectorAll: () => [row] };
  assert.equal(C.harvest(doc, '42').length, 2);
});

test('React 结构缺失时显式失败，不静默宣称队列完成', () => {
  assert.throws(() => C.harvest({ querySelectorAll: () => [] }, '42'), /尚未加载|结构/);
});

function browserHarness({ storage = new Map(), tasks, readHook, resourceNames, importHook } = {}) {
  let serial = 0;
  const timers = [], opened = [], requests = [], ids = new Map(), events = new Map();
  class Element {
    constructor(id) { this.id = id; this.handlers = {}; this.value = id === 'parallel' ? '4' : ''; this.checked = id === 'direct'; }
    addEventListener(name, handler) { this.handlers[name] = handler; }
    append() {}
    replaceChildren() {}
    attachShadow() {
      const controls = new Map();
      const shadow = { activeElement: null, getElementById: id => controls.get(id) };
      Object.defineProperty(shadow, 'innerHTML', { set: html => {
        for (const [, id] of html.matchAll(/id="([^"]+)"/g)) controls.set(id, new Element(id));
      } });
      this.shadow = shadow; return shadow;
    }
  }
  tasks ||= [
    ...Array.from({ length: 6 }, (_, n) => ({ task_id: `d${n}`, node_id: `d${n}`, parent_id: 'p', group_id: '42', task_type: 1 })),
    { task_id: 'v1', node_id: 'v1', parent_id: 'p', group_id: '42', task_type: 1 },
    { task_id: 'v2', node_id: 'v2', parent_id: 'p', group_id: '42', task_type: 1 },
  ];
  const props = { group_id: '42', tasks, nodes: Object.fromEntries(tasks.map(t => [t.node_id, { name: `${t.node_id}.${t.node_id.startsWith('v') ? 'mp4' : 'pptx'}` }])) };
  const row = { __reactFiber$test: { memoizedProps: props } };
  const document = {
    scripts: [{ src: 'https://whut.ai-augmented.com/app/jx-web/js/index-entry.js' }],
    visibilityState: 'visible', getElementById: id => ids.get(id), createElement: () => new Element(),
    querySelectorAll: selector => selector === 'tbody tr' ? [row] : [],
    documentElement: { append: el => ids.set(el.id, el) }, addEventListener() {},
  };
  const locks = new Set();
  const page = {
    performance: { getEntriesByType: () => (resourceNames || ['https://whut.ai-augmented.com/app/jx-web/js/index-test.js']).map(name => ({ name, decodedBodySize: 6000000 })) },
    navigator: { locks: { request: async (name, options, action) => {
      if (locks.has(name)) return action(null);
      locks.add(name); try { return await action({ name }); } finally { locks.delete(name); }
    } } },
    fetch: async () => ({ ok: true, text: async () => 'export { xyApiGet as x };' }),
    Function: () => async url => {
      if (importHook) { const value = await importHook(url); if (value) return value; }
      return { x: async (path, params, headers, timeout) => {
      const request = { method: 'GET', headers: headers, timeout: timeout };
      requests.push({ path, params, headers, timeout });
      const data = readHook ? await readHook(path, params) : { finished: false };
      return { success: true, code: 0, data };
    } }; },
    addEventListener: (name, action) => events.set(name, action),
  };
  page.top = page;
  const sessions = new Map();
  const context = {
    module: { exports: {} }, console, document, unsafeWindow: page, window: page,
    location: { hostname: 'whut.ai-augmented.com', pathname: '/app/jx-web/mycourse/42/task', hash: '' },
    crypto: { randomUUID: () => `fixture-${++serial}` }, URL, URLSearchParams,
    setTimeout, clearTimeout, setInterval: action => { timers.push(action); return timers.length; }, clearInterval() {},
    sessionStorage: { getItem: k => sessions.get(k), setItem: (k, v) => sessions.set(k, v) },
    GM_getValue: (k, fallback) => storage.has(k) ? structuredClone(storage.get(k)) : fallback,
    GM_setValue: (k, v) => storage.set(k, structuredClone(v)),
    GM_openInTab: (url, options) => { const tab = { url, options, closed: false, close() { this.closed = true; } }; opened.push(tab); return tab; },
  };
  vm.runInNewContext(fs.readFileSync(require.resolve('./理工智课1.1.user.js'), 'utf8'), context);
  const getJob = () => structuredClone(storage.get('whut-watch-v1:job:42'));
  return {
    core: context.module.exports, storage, opened, requests, timers, events, getJob,
    panel: () => ids.get('whut-watch-host').shadow,
    click: id => ids.get('whut-watch-host').shadow.getElementById(id).handlers.click(),
  };
}

test('实际控制器模拟：首批两文档核验后升四并发，全部文档结束才启动视频', async () => {
  const h = browserHarness();
  await h.core.boot(); await h.click('start'); await h.timers[0]();
  let job = h.getJob();
  assert.equal(job.tasks.filter(t => t.status === 'running').length, 2);
  assert.ok(h.opened.every(t => t.options.active === false));
  function finishRunning() {
    job = h.getJob();
    for (const task of job.tasks.filter(t => t.status === 'running')) {
      task.openedAt = Date.now() - 1000;
      h.storage.set(`whut-watch-v1:worker:42:${task.ticket}`, { state: 'success', verified: true, at: Date.now() });
    }
    h.storage.set('whut-watch-v1:job:42', job);
  }
  finishRunning(); await h.timers[0](); job = h.getJob();
  assert.equal(job.tasks.filter(t => t.status === 'running').length, 4);
  assert.ok(job.tasks.filter(t => t.status === 'running').every(t => t.kind === 'document'));
  finishRunning(); await h.timers[0](); job = h.getJob();
  assert.equal(job.tasks.filter(t => t.status === 'running').length, 1);
  assert.equal(job.tasks.find(t => t.status === 'running').kind, 'video');
  assert.equal(h.opened.at(-1).options.active, true);
  await h.click('stop');
  assert.ok(h.opened.every(t => t.closed));
  assert.equal(h.getJob().state, 'stopped');
});

test('实际控制器模拟：刷新后可接管运行队列，保留存活任务且不重复打开', async () => {
  const storage = new Map();
  const task = { id: 'd1', nodeId: 'd1', parentId: 'p', name: 'd1.pptx', kind: 'document', status: 'running', ticket: 'old-ticket', attempts: 1, openedAt: Date.now() };
  storage.set('whut-watch-v1:job:42', { runId: 'old-run', groupId: '42', owner: 'old-owner', state: 'running', tasks: [task], parallel: 4, direct: true, heartbeat: Date.now() });
  storage.set('whut-watch-v1:worker:42:old-ticket', { state: 'working', at: Date.now(), message: '等待文档计时' });
  const h = browserHarness({ storage }); await h.core.boot();
  assert.equal(h.panel().getElementById('resume').disabled, false);
  await h.click('resume'); await h.timers[0]();
  assert.equal(h.getJob().tasks[0].ticket, 'old-ticket');
  assert.equal(h.opened.length, 0);
  await h.click('stop');
});

test('实际控制器模拟：最终服务器核验否定前端成功，不会输出虚假成功', async () => {
  const tasks = [{ task_id: 'd1', task_type: 1, node_id: 'd1', parent_id: 'p', group_id: '42' }];
  const h = browserHarness({ tasks }); await h.core.boot(); await h.click('start'); await h.timers[0]();
  const task = h.getJob().tasks[0];
  h.storage.set(`whut-watch-v1:worker:42:${task.ticket}`, { state: 'success', verified: true, at: Date.now() });
  await h.timers[0]();
  assert.equal(h.getJob().state, 'complete');
  assert.equal(h.getJob().tasks[0].status, 'failed');
  assert.match(h.getJob().tasks[0].note, /最终服务器状态未确认/);
});

test('实际控制器模拟：登录失效会暂停队列，不启动后续任务', async () => {
  const h = browserHarness(); await h.core.boot(); await h.click('start'); await h.timers[0]();
  const task = h.getJob().tasks.find(t => t.status === 'running');
  h.storage.set(`whut-watch-v1:worker:42:${task.ticket}`, { state: 'auth', at: Date.now(), message: '登录已失效' });
  await h.timers[0]();
  assert.equal(h.getJob().state, 'paused');
  assert.equal(h.opened.length, 2);
  await h.click('stop');
});

test('严格查询白名单：开始时不发送 _whut_watch 等网站不接受的附加参数', async () => {
  const h = browserHarness({ readHook: async (path, params) => {
    assert.equal(path, '/api/jx-iresource/resource/task/studentFinishInfo/v2');
    assert.deepEqual(Object.keys(params).sort(), ['group_id', 'node_id', 'task_id']);
    assert.equal(params.group_id, '42');
    return { finished: false };
  } });
  await h.core.boot(); await h.click('start'); await h.timers[0]();
  assert.equal(h.getJob().state, 'running');
  assert.equal(h.requests.length, 8);
  assert.ok(h.requests.every(request => request.headers['Cache-Control'] === 'no-cache'));
  assert.equal(h.opened.length, 2);
  await h.click('stop');
});

test('压缩后原函数名消失，仍能从模块导出定位 GET 方法；不把 POST 识别成 GET', () => {
  const a = (u, q, h = {}, t) => fetch(u, { method: 'GET', headers: h, timeout: t });
  const b = (u, q, h = {}, t) => fetch(u, { method: 'POST', headers: h, timeout: t });
  assert.equal(C.findGetExport({ z: a, g: b }), 'z');
  assert.equal(C.nativeGetFunction(b), false);
  assert.equal(C.findGetExport({ x: a, alias: a }), 'x');
  assert.equal(C.findGetExport({ x: () => 'GET', y: b }), null);
});

test('多个不同 GET 导出时不猜测，已验证的具体导出可消除歧义', () => {
  const a = (u, q, h, t) => fetch(u, { method: 'GET', headers: h, timeout: t });
  const b = (u, q, h, t) => fetch(u, { method: 'GET', headers: h, timeout: t + 1 });
  assert.equal(C.findGetExport({ x: a, y: b }), null);
  assert.equal(C.findGetExport({ x: a, y: b }, 'x'), 'x');
});

test('模块地址限制在本学校原有应用，不接受外站或伪造地址', () => {
  assert.equal(C.applicationModuleURL('https://whut.ai-augmented.com/app/jx-web/js/index-abc.js?v=1'), 'https://whut.ai-augmented.com/app/jx-web/js/index-abc.js?v=1');
  assert.equal(C.applicationModuleURL('https://example.com/app/jx-web/js/index-abc.js'), null);
  assert.equal(C.applicationModuleURL('https://whut.ai-augmented.com/app/jx-web/js/index-abc.js#copy'), null);
  assert.equal(C.applicationModuleURL('https://name:password@whut.ai-augmented.com/app/jx-web/js/index-abc.js'), null);
});

test('控制页保存无凭证接口描述，资源记录缺失的新页面复用相同入口的已验证模块', async () => {
  const storage = new Map();
  const first = browserHarness({ storage }); await first.core.boot(); await first.click('start');
  const saved = first.getJob().apiDescriptor;
  assert.equal(saved.moduleURL, 'https://whut.ai-augmented.com/app/jx-web/js/index-test.js');
  assert.equal(saved.exportName, 'x');
  assert.deepEqual(Object.keys(saved).sort(), ['entryURL', 'exportName', 'moduleURL']);
  await first.click('stop');
  const imports = [];
  const second = browserHarness({ storage, resourceNames: [], importHook: url => { imports.push(url); } });
  await second.core.boot(); await second.click('start');
  assert.equal(second.getJob().state, 'running');
  assert.equal(imports[0], saved.moduleURL);
  await second.click('stop');
});

test('首次观看返回 60009 时表示历史未建立，可以从零开始实际播放', async () => {
  const result = await C.readMediaHistory(async path => {
    assert.equal(path, '/vod/duration/9000000000000000002');
    throw new C.WatchError('media history not exist', 'task', 60009);
  }, '9000000000000000002');
  assert.deepEqual(result, { historyExists: false, played: 0, duration: 0, watched_duration: 0 });
});

test('缺少历史的兼容不吞掉登录失效、其他错误码或未知服务器错误', async () => {
  for (const error of [
    new C.WatchError('media history not exist', 'auth', 60009),
    new C.WatchError('media history not exist', 'task', 60010),
    new C.WatchError('resource missing', 'task', 60009),
    new C.WatchError('network timeout'),
  ]) await assert.rejects(C.readMediaHistory(async () => { throw error; }, 'id'), caught => caught === error);
});

test('存在的历史数值被正常读取，异常观看时长不会伪装成零', async () => {
  const record = await C.readMediaHistory(async () => ({ played: '12.5', watched_duration: '10.2', duration: 100 }), 'id');
  assert.equal(record.historyExists, true);
  assert.equal(record.played, 12.5);
  assert.equal(record.watched_duration, 10.2);
  await assert.rejects(C.readMediaHistory(async () => ({ watched_duration: 'invalid' }), 'id'), /时长无效/);
  await assert.rejects(C.readMediaHistory(async () => ({ watched_duration: -1 }), 'id'), /时长无效/);
});

function autoplayHarness({ muted = false, play, active, wait } = {}) {
  const video = { muted, paused: true, ended: false };
  const calls = [], notices = [], waits = [];
  const hooks = {
    active: active || (async () => {}),
    play: async () => { calls.push(video.muted); if (play) await play(video, calls.length); else video.paused = false; },
    wait: async ms => { waits.push(ms); if (wait) await wait(video, waits.length); },
    notify: text => notices.push(text),
  };
  return { video, hooks, calls, notices, waits };
}
const playError = name => Object.assign(new Error(name), { name });

test('有声自动播放被拒绝后自动静音重试，不等待用户点击', async () => {
  const h = autoplayHarness({ play: async video => {
    if (!video.muted) throw playError('NotAllowedError');
    video.paused = false;
  } });
  await C.startVideoPlayback(h.video, h.hooks);
  assert.deepEqual(h.calls, [false, true]);
  assert.equal(h.video.paused, false);
  assert.equal(h.video.muted, true);
  assert.deepEqual(h.waits, []);
  assert.match(h.notices[0], /静音启动/);
});

test('有声播放可用时保留声音；已经播放时不重复发起 play', async () => {
  const h = autoplayHarness();
  await C.startVideoPlayback(h.video, h.hooks);
  await C.startVideoPlayback(h.video, h.hooks);
  assert.deepEqual(h.calls, [false]);
  assert.equal(h.video.muted, false);
});

test('静音也被拒绝时才等待真实手动播放，不伪造点击', async () => {
  const h = autoplayHarness({ muted: true,
    play: async () => { throw playError('NotAllowedError'); },
    wait: async (video, count) => { if (count === 2) video.paused = false; },
  });
  await C.startVideoPlayback(h.video, h.hooks);
  assert.deepEqual(h.calls, [true]);
  assert.deepEqual(h.waits, [1000, 1000]);
  assert.match(h.notices[0], /手动/);
});

test('网站重置静音也不无限重试；等待手动播放最多 60 秒', async () => {
  const h = autoplayHarness({ play: async video => {
    video.muted = false; throw playError('NotAllowedError');
  } });
  await assert.rejects(C.startVideoPlayback(h.video, h.hooks), /手动启动播放超时/);
  assert.equal(h.calls.length, 2);
  assert.equal(h.waits.reduce((a, b) => a + b, 0), 60000);
});

test('播放器短暂中断会重试两次，持续中断及其他错误不会无限重试', async () => {
  const h = autoplayHarness({ play: async (video, count) => {
    if (count <= 2) throw playError('AbortError');
    video.paused = false;
  } });
  await C.startVideoPlayback(h.video, h.hooks);
  assert.equal(h.calls.length, 3);
  assert.deepEqual(h.waits, [150, 150]);
  const broken = autoplayHarness({ play: async () => { throw playError('AbortError'); } });
  await assert.rejects(C.startVideoPlayback(broken.video, broken.hooks), { name: 'AbortError' });
  assert.equal(broken.calls.length, 3);
  const unsupported = autoplayHarness({ play: async () => { throw playError('NotSupportedError'); } });
  await assert.rejects(C.startVideoPlayback(unsupported.video, unsupported.hooks), { name: 'NotSupportedError' });
  assert.equal(unsupported.calls.length, 1);
});

test('自动启动及手动等待都遵守停止命令，不在取消后恢复播放', async () => {
  let checks = 0;
  const cancelled = new C.WatchError('队列停止', 'cancelled');
  const h = autoplayHarness({
    active: async () => { if (++checks >= 2) throw cancelled; },
    play: async () => { throw playError('NotAllowedError'); },
  });
  await assert.rejects(C.startVideoPlayback(h.video, h.hooks), error => error === cancelled);
  assert.equal(h.calls.length, 1);
  const manual = autoplayHarness({ muted: true, play: async () => { throw playError('NotAllowedError'); },
    wait: async () => { throw cancelled; },
  });
  await assert.rejects(C.startVideoPlayback(manual.video, manual.hooks), error => error === cancelled);
  assert.equal(manual.calls.length, 1);
});

test('原生 Aliplayer 先初始化懒加载源并隐藏封面，再等待媒体实际启动', async () => {
  const order = [];
  const h = autoplayHarness({ muted: true, play: async video => {
    order.push('media');
    assert.equal(video.readyState, 1);
    assert.equal(video.cover, false);
    video.paused = false;
  } });
  h.video.readyState = 0; h.video.cover = true;
  h.hooks.player = () => ({ tag: h.video, play() {
    order.push('sdk'); h.video.readyState = 1; h.video.cover = false;
  } });
  await C.startVideoPlayback(h.video, h.hooks);
  assert.deepEqual(order, ['sdk', 'media']);
  assert.equal(h.video.paused, false);
});

test('媒体已播放时仍同步原 SDK 封面；其他视频的 SDK 不会被调用', async () => {
  const h = autoplayHarness();
  h.video.paused = false;
  let sdkStarts = 0;
  h.hooks.player = () => ({ tag: h.video, play() { sdkStarts++; } });
  await C.startVideoPlayback(h.video, h.hooks);
  assert.equal(sdkStarts, 1);
  assert.equal(h.calls.length, 1);
  const foreign = autoplayHarness();
  foreign.hooks.player = () => ({ tag: {}, play() { throw Error('不能控制其他视频'); } });
  await C.startVideoPlayback(foreign.video, foreign.hooks);
  assert.equal(foreign.video.paused, false);
});

test('队列停止时原生 SDK 和媒体播放都不会调用', async () => {
  const h = autoplayHarness({ active: async () => { throw new C.WatchError('队列停止', 'cancelled'); } });
  h.hooks.player = () => ({ tag: h.video, play() { throw Error('取消后不应启动 SDK'); } });
  await assert.rejects(C.startVideoPlayback(h.video, h.hooks), /队列停止/);
  assert.equal(h.calls.length, 0);
});

function firstPlayHarness({ persist = true, failAfterPause = false } = {}) {
  let elapsed = 0, saved = 0, created = false, starts = 0, reads = 0, waited = 0;
  const rates = [], notices = [];
  const video = {
    playbackRate: 8, paused: true, ended: false,
    get currentTime() { return elapsed; },
    set currentTime(_) { throw new Error('初始化不能跳转播放位置'); },
    pause() { if (!this.paused && elapsed > 3 && persist) { saved = elapsed; created = true; } this.paused = true; },
  };
  const read = () => C.readMediaHistory(async () => {
    reads++;
    if (failAfterPause && reads > 1) throw new C.WatchError('登录已失效', 'auth');
    if (!created) throw new C.WatchError('media history not exist', 'task', 60009);
    return { watched_duration: saved, played: elapsed, duration: 100 };
  }, 'id');
  const hooks = {
    notify: text => notices.push(text), active: async () => {},
    start: async () => { starts++; video.paused = false; },
    wait: async ms => { waited += ms; if (!video.paused) { rates.push(video.playbackRate); elapsed += ms / 1000 * video.playbackRate; } },
  };
  return { video, read, hooks, rates, notices, elapsed: () => elapsed, starts: () => starts, waited: () => waited };
}

test('首次历史初始化优先 16 倍实际播放一小段，不跳播；随后恢复原倍速', async () => {
  const h = firstPlayHarness();
  const result = await C.initializeVideoHistory(h.video, h.read, h.hooks);
  assert.equal(result.historyExists, true);
  assert.ok(result.watched_duration >= 4.5 && result.watched_duration < 6);
  assert.equal(result.watched_duration, h.elapsed());
  assert.ok(h.rates.every(rate => rate === 16));
  assert.equal(h.starts(), 1);
  assert.equal(h.video.playbackRate, 8);
  assert.equal(h.video.paused, true);
  assert.match(h.notices[0], /首次观看/);
  assert.ok(h.waited() < 1000, '不应保留旧版的数秒固定等待');
});

test('已有观看历史不重复做首次播放初始化', async () => {
  const h = firstPlayHarness();
  const result = await C.initializeVideoHistory(h.video, async () => ({ historyExists: true, watched_duration: 10 }), h.hooks);
  assert.equal(result.watched_duration, 10);
  assert.equal(h.starts(), 0);
  assert.equal(h.elapsed(), 0);
});

test('真实播放后记录尚未可读时保留未建立状态，允许继续正常播放', async () => {
  const h = firstPlayHarness({ persist: false });
  const result = await C.initializeVideoHistory(h.video, h.read, h.hooks);
  assert.equal(result.historyExists, false);
  assert.equal(result.watched_duration, 0);
  assert.ok(h.elapsed() > 0);
});

test('首次播放后的服务器错误仍会抛出，同时确保暂停并恢复原倍速', async () => {
  const h = firstPlayHarness({ failAfterPause: true });
  await assert.rejects(C.initializeVideoHistory(h.video, h.read, h.hooks), /登录已失效/);
  assert.equal(h.video.paused, true);
  assert.equal(h.video.playbackRate, 8);
});

test('自建任务的离开提示只在核验后主动退出、停止或失效时忽略；运行和暂停时保留', () => {
  const job = { runId: 'run', state: 'running', tasks: [{ id: 'id', ticket: 'ticket', status: 'running' }] };
  assert.equal(C.allowOwnedTaskExit(job, 'run', 'id', 'ticket'), false);
  assert.equal(C.allowOwnedTaskExit({ ...job, state: 'paused' }, 'run', 'id', 'ticket'), false);
  assert.equal(C.allowOwnedTaskExit(job, 'run', 'id', 'ticket', true), true);
  assert.equal(C.allowOwnedTaskExit({ ...job, state: 'stopped' }, 'run', 'id', 'ticket'), true);
  assert.equal(C.allowOwnedTaskExit(job, 'older-run', 'id', 'ticket'), true);
  assert.equal(C.allowOwnedTaskExit(job, 'run', 'id', 'older-ticket'), true);
});

function continuousPlaybackHarness({ duration = 1000, accounting = 'media', readDelay = 0, maxRate = 16, stall = false, readErrorAfter = Infinity } = {}) {
  let wall = 0, position = 0, rate = 1, credit = 0, unsavedMedia = 0, unsavedWall = 0, reads = 0, starts = 0;
  const listeners = new Map(), pauses = [], seeks = [], rateChanges = [], remembered = [], requests = [];
  const emit = name => { for (const fn of listeners.get(name) || []) fn(); };
  const flush = () => {
    if (unsavedMedia > 3) { credit += accounting === 'media' ? unsavedMedia : unsavedWall; unsavedMedia = 0; unsavedWall = 0; }
  };
  const video = {
    duration, paused: true, ended: false, seeking: false, error: null,
    get currentTime() { return position; },
    set currentTime(value) { this.seeking = true; emit('seeking'); seeks.push(value); position = value; this.ended = false; this.seeking = false; emit('seeked'); },
    get playbackRate() { return rate; },
    set playbackRate(value) { if (value > maxRate) throw new RangeError('Unsupported speed'); rate = value; rateChanges.push(value); },
    pause() { pauses.push({ position, wall }); if (!this.paused) flush(); this.paused = true; },
    addEventListener(name, fn) { if (!listeners.has(name)) listeners.set(name, new Set()); listeners.get(name).add(fn); },
    removeEventListener(name, fn) { listeners.get(name)?.delete(fn); },
  };
  function advance(ms) {
    for (let left = ms; left > 0;) {
      const step = Math.min(left, 100); left -= step; wall += step;
      if (video.paused || stall) continue;
      const amount = Math.min(duration - position, step / 1000 * rate);
      position += amount; unsavedMedia += amount; unsavedWall += amount / rate;
      if (unsavedMedia > 30) flush();
      emit('timeupdate');
      if (position >= duration) { video.ended = true; video.paused = true; flush(); }
    }
  }
  const hooks = {
    now: () => wall, preferredRate: 16, active: async () => true,
    start: async () => { starts++; video.paused = false; },
    wait: async ms => { advance(ms); if (wall > 3000000) throw Error('simulation did not finish'); },
    read: async () => {
      reads++; requests.push({ paused: video.paused, position, rate });
      if (reads > readErrorAfter) throw new C.WatchError('登录已失效', 'auth');
      advance(readDelay);
      return { historyExists: credit > 0, watched_duration: credit, played: position, duration };
    },
    finish: async () => credit >= duration * 0.95,
    remember: value => remembered.push(value), notify() {},
  };
  return { video, hooks, listeners, pauses, seeks, rateChanges, remembered, requests, wall: () => wall, starts: () => starts };
}

test('连续 16 倍播放期间后台查询不主动暂停，只有最终完成时停止', async () => {
  const h = continuousPlaybackHarness();
  await C.monitorContinuousVideo(h.video, h.hooks);
  assert.ok(h.requests.length >= 5);
  assert.ok(h.requests.filter(r => r.position < h.video.duration * 0.95).every(r => !r.paused));
  assert.ok(h.pauses.every(p => p.position >= h.video.duration * 0.95));
  assert.ok(h.rateChanges.every(rate => rate === 16));
  assert.equal(h.seeks.length, 0);
  assert.equal(h.starts(), 1);
  assert.ok(h.wall() < 65000, '1000 秒视频无需额外累计数十秒暂停');
  assert.ok([...h.listeners.values()].every(set => set.size === 0));
});

test('异步进度查询期间视频继续推进，不能漏算查询期间播放的媒体时间', async () => {
  const h = continuousPlaybackHarness({ readDelay: 1000 });
  await C.monitorContinuousVideo(h.video, h.hooks);
  assert.ok(h.rateChanges.every(rate => rate === 16));
  assert.equal(h.seeks.length, 0);
  assert.ok(h.pauses.every(p => p.position >= h.video.duration * 0.95));
});

test('浏览器拒绝 16 倍时使用实际支持的 8 倍，不因正常保存尾段而降速', async () => {
  const h = continuousPlaybackHarness({ maxRate: 8 });
  await C.monitorContinuousVideo(h.video, h.hooks);
  assert.ok(h.rateChanges.every(rate => rate === 8));
  assert.equal(h.seeks.length, 0);
  assert.equal(h.remembered.at(-1), 8);
});

test('服务端只计实际墙钟时间时，累计验证会发现倍速不足并逐级降速', async () => {
  const h = continuousPlaybackHarness({ accounting: 'wall' });
  await C.monitorContinuousVideo(h.video, h.hooks);
  assert.deepEqual([...new Set(h.rateChanges)], [16, 8, 4, 2, 1]);
  assert.ok(h.seeks.length >= 4);
  assert.equal(h.remembered.at(-1), 1);
});

test('短视频未达到首次后台抽查区间也能在自然结束后核验完成', async () => {
  const h = continuousPlaybackHarness({ duration: 20 });
  await C.monitorContinuousVideo(h.video, h.hooks);
  assert.equal(h.video.ended, true);
  assert.equal(h.remembered.at(-1), 16);
  assert.equal(h.seeks.length, 0);
});

test('原播放器没有推进时仍会超时报错，不会因为取消暂停而无限等待', async () => {
  const h = continuousPlaybackHarness({ stall: true });
  await assert.rejects(C.monitorContinuousVideo(h.video, h.hooks), /60 秒未推进/);
  assert.ok(h.wall() <= 61000);
  assert.deepEqual([...new Set(h.rateChanges)], [16], '缓冲停滞不应被误判成服务端拒绝倍速');
  assert.ok([...h.listeners.values()].every(set => set.size === 0));
});

test('后台查询登录失效仍抛出，清理监听器，不能当作进度未增长而继续', async () => {
  const h = continuousPlaybackHarness({ readErrorAfter: 1 });
  await assert.rejects(C.monitorContinuousVideo(h.video, h.hooks), error => error.kind === 'auth');
  assert.ok([...h.listeners.values()].every(set => set.size === 0));
});

test('保存结果即时可读则不固定等待，尚未保存时仅按需轮询', async () => {
  const waits = []; let reads = 0;
  const existing = await C.pollHistory(async () => ({ historyExists: true }), r => r.historyExists, { wait: async ms => waits.push(ms) });
  assert.equal(existing.historyExists, true);
  assert.equal(waits.length, 0);
  await C.pollHistory(async () => ({ historyExists: ++reads >= 3 }), r => r.historyExists, { wait: async ms => waits.push(ms) });
  assert.deepEqual(waits, [200, 200]);
});

test('用户暂停两分钟后继续，不会被当作视频停滞或倍速不计入', async () => {
  const h = continuousPlaybackHarness(); let paused = false;
  h.hooks.active = async () => {
    if (!paused && h.wall() >= 4000) {
      paused = true; h.video.pause(); await h.hooks.wait(120000); return false;
    }
    return true;
  };
  await C.monitorContinuousVideo(h.video, h.hooks);
  assert.equal(paused, true);
  assert.ok(h.rateChanges.every(rate => rate === 16));
  assert.equal(h.seeks.length, 0);
  assert.ok(h.wall() >= 120000);
});
